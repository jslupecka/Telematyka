/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gra.telematyka;

import Memo.Memo;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Pobiera imie gracza z okna
 * Możliość wejścia do rankingu gry Memo
 * @author Joanna
 */
public class OknoImieMemo extends JFrame{
    OknoImieMemo(){
setResizable(false);
setSize(1000,600);
//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

JPanel p = new JPanel(new GridBagLayout());
p.setBackground(new Color(183, 228, 240));

GridBagConstraints c = new GridBagConstraints();
c.insets=new Insets(10,10,10,10);

JLabel opis=new JLabel("Wpisz swoje imię i rozpocznij grę");
opis.setFont(new Font("Serif", Font.PLAIN, 50));
c.gridx=0;
c.gridy=1;
p.add(opis,c);

JTextField name=new JTextField("", 20);

c.gridx=0;
c.gridy=2;
p.add(name,c);

ImageIcon rozpocznij = new ImageIcon("obrazy\\rozpocznij.png");
JLabel label = new JLabel("", rozpocznij, JLabel.CENTER);
label.addMouseListener(new MouseAdapter()
{public void mouseClicked(MouseEvent arg0)
{
    String imie=name.getText();
    try {
        Memo.start(imie);
    } catch (IOException ex) {
        Logger.getLogger(OknoImie.class.getName()).log(Level.SEVERE, null, ex);
    }
}
        });

c.gridx=0;
c.gridy=3;
p.add(label,c);

ImageIcon ranking = new ImageIcon("obrazy\\ranking.png");//("C:\\Users\\Joanna\\Desktop\\obrazy-wjp\\nauka.png");
JLabel label3 = new JLabel("", ranking, JLabel.CENTER);
label3.addMouseListener(new MyMouseAdapter(this)
{public void mouseClicked(MouseEvent arg0)
{
String plik=("obrazy\\rankingMemo.txt");
    ArrayList<Dane> list = new ArrayList<>();
    try {
        FileReader fr=new FileReader(plik);
        BufferedReader a=new BufferedReader(fr);
        
         String line=null;
        while ((line = a.readLine())!= null) {
            String[] arrayLine= line.split("\\s+");  
            String imie = arrayLine[0];
            String punkty = arrayLine[1];
            int p = Integer.parseInt(punkty);
            list.add(new Dane(p,imie));   }
        
    } catch (FileNotFoundException ex) {
        Logger.getLogger(OknoGlowne.class.getName()).log(Level.SEVERE, null, ex);
    } catch (IOException ex) {
        Logger.getLogger(OknoGlowne.class.getName()).log(Level.SEVERE, null, ex);
             
    }
    Collections.sort(list);
    RankingMemo r=new RankingMemo(list);
    
    r.setVisible(true);
    
    
}
});

c.gridx=0;
c.gridy=4;
p.add(label3,c);



add(p,BorderLayout.CENTER);
    
}}
