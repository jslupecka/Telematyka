/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gra.telematyka;


/**
 *
 * @author Joanna Slupecka
 */

/**
 * 
 *  Klasa przechowująca informacje o graczu (imie i punkty)
 */


public class Dane implements Comparable <Dane> {
    public int punkty;
    public String imie;
     /**
     * inicjalizacja obiektu Dane?
     * @param punkty punkty gracza
     * @param imie imie gracza
     */
    Dane(int punkty, String imie)
    {
        this.imie=imie;
        this.punkty=punkty;
    }
/**
 * 
 * @param o wynik
 * @return sortuje wyniki
 */
    @Override
    public int compareTo(Dane o) 
    {
    return o.punkty-this.punkty;
    }
    
    
    }
