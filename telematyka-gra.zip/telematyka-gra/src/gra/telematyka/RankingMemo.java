/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gra.telematyka;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * ranking gry Memo
 * @author Joanna
 */
   public class RankingMemo extends JFrame{
    RankingMemo (ArrayList<Dane> a){
setResizable(false);
setSize(1000,600);
//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

JPanel p = new JPanel(new GridBagLayout());
p.setBackground(new Color(183, 228, 240));
JPanel p2 = new JPanel(new GridBagLayout());
p2.setBackground(new Color(183, 228, 240));
GridBagConstraints c = new GridBagConstraints();
c.insets=new Insets(10,10,10,10);

JLabel opis=new JLabel("Gra Memo-Ranking");
opis.setFont(new Font("Serif", Font.PLAIN, 50));
c.gridx=0;
c.gridy=1;
p.add(opis,c);
add(p,BorderLayout.NORTH);


int y=2;
int nr=1;
for(Dane d :a)
{
 String wpis = nr+ ". "+ d.imie + " " + Integer.toString(d.punkty)+'\n';
 JLabel wp =new JLabel(wpis);
c.gridx=0;
c.gridy=y;
y++;
nr++;
p.add(wp,c);

}
add(p2,BorderLayout.CENTER);
    }

    public RankingMemo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
