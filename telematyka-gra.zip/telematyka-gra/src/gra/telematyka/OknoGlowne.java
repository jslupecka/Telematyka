package gra.telematyka;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *Okno głowne gry
 * @author Joanna
 */
public class OknoGlowne extends JFrame{
    OknoGlowne(){
setResizable(false);
setSize(1000,600);
//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

JPanel p = new JPanel(new GridBagLayout());
p.setBackground(new Color(183, 228, 240));

GridBagConstraints c = new GridBagConstraints();
c.insets=new Insets(10,10,10,10);

JLabel opis=new JLabel("Witamy w grze");
opis.setFont(new Font("Serif", Font.PLAIN, 50));
c.gridx=0;
c.gridy=1;
p.add(opis,c);
ImageIcon rozpocznij = new ImageIcon("obrazy\\labirynt.png");
JLabel label = new JLabel("", rozpocznij, JLabel.CENTER);
label.addMouseListener(new MyMouseAdapter(this)
{public void mouseClicked(MouseEvent arg0)
{
    OknoImie i=new OknoImie();
    i.setVisible(true);
}
});

c.gridx=0;
c.gridy=2;
p.add(label,c);
ImageIcon ranking = new ImageIcon("obrazy\\memo.png");
JLabel label2 = new JLabel("", ranking, JLabel.CENTER);
label2.addMouseListener(new MyMouseAdapter(this)
{public void mouseClicked(MouseEvent arg0)
{
    OknoImieMemo i=new OknoImieMemo();
    i.setVisible(true);
   
}
});

c.gridx=0;
c.gridy=3;
p.add(label2,c);

ImageIcon instrukcja = new ImageIcon("obrazy\\instrukcja.png");
JLabel label3 = new JLabel("", instrukcja, JLabel.CENTER);
label3.addMouseListener(new MyMouseAdapter(this)
{@Override
public void mouseClicked(MouseEvent arg0)
{
 infoBox();
}
});

c.gridx=0;
c.gridy=4;
p.add(label3,c);

add(p,BorderLayout.CENTER);
    }
    
    
    public void infoBox()
    {
        JOptionPane.showMessageDialog(null, "1. Upewnij się, że tablet jest podłączony do komputera. \n"
                + "2. Wybierz grę. \n3.Wpisz swoje imię. "
                + "\n4.Kliknij 'Rozpocznij grę', aby rozpocząć grę lub 'Ranking', aby sprawdzić wyniki. \n"
                + "5.Gra labirynt-poprowadz kursor przez wyznaczony obszar, uważająć, aby jej nie przekroczyć jego linii brzegowej "
                + "\n6.Gra memo-odkrywaj kolejne pary i baw się dobrze ;)", "Instrukcja", JOptionPane.INFORMATION_MESSAGE);
    }
   

  
}
