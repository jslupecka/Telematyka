/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gra.telematyka;

import java.awt.event.MouseAdapter;
import javax.swing.JFrame;

/**
 * Klasa obslugująca mysz (uzywana do zamykania okien przy otwieraniu innych)
 * @author Joanna
 */
public class MyMouseAdapter extends MouseAdapter {
    public JFrame frame;
    /**
     * inicjalizuje obiekt frame 
     * @param frame okno 
     */
    MyMouseAdapter(JFrame frame) {
        this.frame = frame;
    }
}
