/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labirynt;

import gra.telematyka.OknoGlowne;
import gra.telematyka.OknoGlowne;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.JOptionPane;


/**
 *
 * @author Joanna
 * Klasa odpowiedzialna za działanie gry labirynt
 */
public class Labirynt extends JComponent implements MouseMotionListener{

   BufferedImage intro;
   BufferedImage level1;
   BufferedImage level2;
   BufferedImage level3;
   BufferedImage level4;
   BufferedImage level5;
   BufferedImage level6;
   BufferedImage gameOver;
   BufferedImage currentLevel;
   public int punkty=0;
   public String imie; 

   public static void start(String imie) throws IOException
   {
        JFrame window = new JFrame("Maze");
        Labirynt game =new Labirynt(imie);
        window.add(game);
        window.pack();
        window.setSize(1000,640);
        window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window.setVisible(true);
        
        game.addMouseMotionListener(game);
   }
    public static void main(String[] args) throws IOException {
start(new String());
        
    }
    private boolean wynikZapisany;

    public Labirynt(String imie) throws IOException {
               this.imie = imie;
        this.intro = ImageIO.read(getClass().getResource("intro.png"));
        this.level1 = ImageIO.read(getClass().getResource("level1.png"));
        this.level2 = ImageIO.read(getClass().getResource("level2.png"));
        this.level3 = ImageIO.read(getClass().getResource("level3.png"));
        this.level4 = ImageIO.read(getClass().getResource("level4.png"));
        this.level5 = ImageIO.read(getClass().getResource("level5.png"));
        this.level6 = ImageIO.read(getClass().getResource("level6.png"));
        this.gameOver = ImageIO.read(getClass().getResource("game over.png"));
        this.currentLevel=intro;
        this.wynikZapisany = false;
    }
    @Override
    public Dimension getPreferredSize(){
        return new Dimension(1000,600);
    }
    
    @Override
    protected void paintComponent(Graphics g){
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0,0,1000,600);
        g.drawImage(currentLevel, 0,0, null);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        //throw new UnsupportedOperationException("Not supported yet.");
       int x = e.getX(); 
       int y = e.getY();
       int color=currentLevel.getRGB(x, y);
     
       
      System.out.println(color);
      System.out.println(String.format("0x%08X", color));
       
       
       if (color == 0xFFA349A4)
       {
           wynikZapisany = false;
           punkty = 0;
           currentLevel=level1;
       }
       if (color==0xFF3F48CC)
       {
           currentLevel=level2;
           punkty=1;
       }
       if (color==0xFFFFF200)
       {
           currentLevel=level3;
           punkty=2;
       }
       if (color==0xFFED1C24) 
       {
           currentLevel=level4;
           punkty=3;
       }
       if (color==0xFF1F97EF) 
       {
           currentLevel=level5;
           punkty=4;
       }
       if (color==0xFFD057A3) 
       {
           currentLevel=level6;
           punkty=5;
       }
              if (color==0xFFFF7F27) 
       {
           currentLevel=intro;
           punkty=0;
       }
       if (color==0xFFFFFFFF) 
       {
             Window win = SwingUtilities.getWindowAncestor(this);
             win.dispose();

                
       }
              
       if ((color==0xFFA8A8FF || color==0xFFB5E61D || color==0xFFFF9562 || color==0xFF887B84 || color==0xFFC3C3C3) && !wynikZapisany)//tła
       {
       
        try {
                wynikZapisany = true;
                zapisz(imie,punkty);
            } catch (IOException ex) {
                Logger.getLogger(Labirynt.class.getName()).log(Level.SEVERE, null, ex);
            }
          currentLevel=gameOver;
          infoBox(punkty);
          
       }
       
       
      repaint();
      
    }
    
           public void zapisz(String imie,int punkty) throws IOException
    {
        String plik=("obrazy\\rankingLabirynt.txt");
        
        FileWriter writer=new FileWriter(plik, true);
        PrintWriter print_line=new PrintWriter(writer);
        print_line.printf("%s "+"%d\n", imie, punkty);
        print_line.close();
                
    }
           
            public void infoBox( int punkty)
    {
        JOptionPane.showMessageDialog(null, "Gratulacje", "Twoj wynik: " + punkty, JOptionPane.INFORMATION_MESSAGE);
    }
    
}



