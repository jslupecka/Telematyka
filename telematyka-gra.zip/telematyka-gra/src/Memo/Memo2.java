/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Memo;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.WindowConstants;
/**
 *
 * @author Go
 */
public class Memo2 extends JFrame implements MouseMotionListener{

   
    public String imie; 
    int punkty;  
    private boolean wynikZapisany;
    
    private List<Card> cards;
    private Card selectedCard;
    private Card c1;
    private Card c2;
    private Timer t;
    
  public int pairs;
   int level;

 JLabel emptyLabel = new JLabel();
 JButton button= new JButton("koniec gry");
 JButton button2= new JButton("dalej");
 
  Container pane = getContentPane();
        
     List<Card> cardsList = new ArrayList<Card>();
     List<Integer> cardVals = new ArrayList<Integer>();

    /**
     * @param args the command line arguments
     */
   
        // TODO code application logic here
       
    
    public static void start(String imie, int punkty, int pairs, int level) throws IOException{
       
         Memo2 b = new Memo2(imie,punkty,pairs,level);
       b.setPreferredSize(new Dimension(1000,600)); 
        b.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        b.pack();
        b.setVisible(true);
    } 
   public Memo2(String imie,int punkty,int pairs, int level){
    this.imie=imie;
    this.wynikZapisany = false;
        this.punkty=punkty;
        this.level=level;
        this.pairs=pairs;
        for (int i = 0; i < pairs; i++){
            cardVals.add(i);
            cardVals.add(i);
        }
        Collections.shuffle(cardVals);

        for (int val : cardVals){
            Card c = new Card();
            c.setId(val);
            c.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ae){
                    selectedCard = c;
                    doTurn();
                }
            });
            cardsList.add(c);
        }
        this.cards = cardsList;
       //timer
        t = new Timer(750, new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    checkCards();
                } catch (IOException ex) {
                    Logger.getLogger(Memo2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        t.setRepeats(false);

        Container pane = getContentPane();
        pane.setLayout(new GridLayout(5,4));
         
        for (Card c : cards){
           pane.add(c);
            pane.add(emptyLabel);
            emptyLabel.setText("poziom:   "+level+"      punkty: "+punkty );
            emptyLabel.setFont(new Font("Serif", Font.BOLD, 18));
    
            pane.add(button);
            
            button.setVisible(false);
            emptyLabel.setVisible(true);
            pane.add(button2);
            button2.setVisible(false);
        }
        setTitle("Memo");
    }

    
 
    public void doTurn(){
        if (c1 == null && c2 == null){
            c1 = selectedCard;
             c1.setFont(c1.getFont().deriveFont(60.0f));
            c1.setText(String.valueOf(c1.getId()));
        }

        if (c1 != null && c1 != selectedCard && c2 == null){
            c2 = selectedCard;
             c2.setFont(c2.getFont().deriveFont(60.0f));
            c2.setText(String.valueOf(c2.getId()));
            t.start();
        }
    }

    public void checkCards() throws IOException{
     this.imie=imie;
        if (c1.getId() == c2.getId()){
            c1.setEnabled(false); 
            c2.setEnabled(false);
          
            c1.setMatched(true); 
            c2.setMatched(true);
            punkty++;
            button.setVisible(true);
            
            
             button.addActionListener(new ActionListener() {
              
                  
     public void actionPerformed(ActionEvent e) {
         
         try {
             wynikZapisany = true;
             zapisz(imie,punkty);
     setVisible(false);    
         } catch (IOException ex) {
             Logger.getLogger(Memo.class.getName()).log(Level.SEVERE, null, ex);
         }
     } 
     }); 
             emptyLabel.setText( "poziom  "+level+"   punkty:  "+punkty);
              
            if (this.isGameWon()){
               // points++;
               button2.setVisible(true);
               pairs++;
               pairs++;
               level++;
               emptyLabel.setText("punkty:  "+punkty);
          
                   button2.addActionListener(new ActionListener() {
              
                  
     public void actionPerformed(ActionEvent e) {

             Memo2 m=new Memo2(imie,punkty,pairs,level);
             
              m.setPreferredSize(new Dimension(1000,600)); 
    
        m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        m.pack();
        m.setVisible(true);
             
             setVisible(false);
     } 
     }); 
               
            }
        }
        
        else{
            c1.setText(""); 
            c2.setText("");
        }
        c1 = null; 
        c2 = null;
    }

    public boolean isGameWon(){
        for(Card c: this.cards){
            if (c.getMatched() == false){
                return false;
            }
        }
        
        return true;
    
}
    
    
             public void zapisz(String imie,int punkty) throws IOException
    {
        String plik=("obrazy\\rankingMemo.txt");
        
        FileWriter writer=new FileWriter(plik, true);
        PrintWriter print_line=new PrintWriter(writer);
        print_line.printf("%s "+"%d\n", imie, punkty);
        print_line.close();
                
    }
           
    @Override
    public void mouseDragged(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
          
}